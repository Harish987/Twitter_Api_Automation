package Twitt_Api;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Trending_Hashtag_Twitter {
	           //allworld  //india //uk  //usa    //isral
	int[] c = {1,2295383,28218,23424977,23424852};
	
	Properties pro=new Properties();
	Logger l=Logger.getLogger("Trending_Hashtag_Twitter");
	
@BeforeTest
	
	public void start() throws Exception {
	
          PropertyConfigurator.configure("C:\\New folder\\Twitter API Automation\\Log4j.properties");	
         FileInputStream f=new FileInputStream("C:\\New folder\\Twitter API Automation\\Data.properties");
		pro.load(f);
}
	@Test
	
	public void get_hashtag_Tweet() throws IOException
{
		
		for(int i=0;i<c.length;i++)
	{
			
			
		RestAssured.baseURI=pro.getProperty("trending");
		
		
		
		Response resp=given().auth().oauth(pro.getProperty("ConsumerKey"),pro.getProperty("ConsumerSecret"),pro.getProperty("Token"),pro.getProperty("TokenSecret")).
		queryParam("id",c[i])
		
		.when().get(pro.getProperty("trendinres")).then().extract().response();
		
		String response=resp.asString();
		l.info(response);
		System.out.println(response);
		
		JsonPath json=new JsonPath(response);
		String tag=json.get("name").toString();
		l.info(tag);
		System.out.println(tag);
			
	}
}
	}

