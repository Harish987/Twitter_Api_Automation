package Twitt_Api;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Bangaloreweather_Twitter 
{

	Properties pro=new Properties();
	Logger L=Logger.getLogger("Bangaloreweather_Twitter");
	
	@BeforeTest
	
	public void base() throws IOException {
	   
		PropertyConfigurator.configure("C:\\New folder\\Twitter API Automation\\Log4j.properties");
		
		FileInputStream f=new FileInputStream("C:\\New folder\\Twitter API Automation\\Data.properties");
		pro.load(f);
		
	}
	
	@Test
	
public void Bangweather()  {
		
		
		RestAssured.baseURI=pro.getProperty("bang");
		
		Response resp=given().auth().oauth(pro.getProperty("ConsumerKey"),pro.getProperty("ConsumerSecret"),pro.getProperty("Token"),pro.getProperty("TokenSecret")).	
				 
				queryParam("q",pro.getProperty("bangweather"))
				.when().get(pro.getProperty("bangres"))
				
				.then().assertThat().statusCode(200).and().contentType(ContentType.JSON).extract().response();
				
				String response=resp.asString();
				L.info(response);
				System.out.println(response);
				
	
}
}
