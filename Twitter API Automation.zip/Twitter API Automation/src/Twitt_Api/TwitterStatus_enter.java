package Twitt_Api;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TwitterStatus_enter {
	
	
	Properties pro=new Properties(); 
	Logger l=Logger.getLogger("TwitterStatus_enter");
	
@BeforeTest
	
	public void start() throws Exception {
	
	     PropertyConfigurator.configure("C:\\New folder\\Twitter API Automation\\Log4j.properties");	
		FileInputStream f=new FileInputStream("C:\\New folder\\Twitter API Automation\\Data.properties");
		pro.load(f);
}
	
	@Test
	
	public void get_Tweet() throws IOException
	{

		
		
		RestAssured.baseURI=pro.getProperty("status");
		
		Response resp=given().auth().oauth(pro.getProperty("ConsumerKey"),pro.getProperty("ConsumerSecret"),pro.getProperty("Token"),pro.getProperty("TokenSecret")).
		queryParam("count","5")
		
		.when().get(pro.getProperty("ststusres")).then().extract().response();
		
		String response=resp.asString();
		l.info(response);
		System.out.println(response);
		
		JsonPath json=new JsonPath(response);
		String id=json.get("id").toString();
		l.info(id);
		System.out.println(id);
		
		String text=json.get("text").toString();
		l.info(id);
		System.out.println(text);
}
}
