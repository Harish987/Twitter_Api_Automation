package Twitt_Api;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Post_twitter {
	
	Properties pro=new Properties();
	Logger l=Logger.getLogger("Post_twitter");
	
@BeforeTest
	
	public void start() throws Exception {
	
	    PropertyConfigurator.configure("C:\\New folder\\Twitter API Automation\\Log4j.properties");
		FileInputStream f=new FileInputStream("C:\\New folder\\Twitter API Automation\\Data.properties");
		pro.load(f);
}
	@Test 
	
	public void get_Tweet() throws Exception
	{
		
		RestAssured.baseURI=pro.getProperty("post");
		
		Response resp=given().auth().oauth(pro.getProperty("ConsumerKey"),pro.getProperty("ConsumerSecret"),pro.getProperty("Token"),pro.getProperty("TokenSecret")).
		
		queryParam("status",pro.getProperty("postin"))
		
		.when().post(pro.getProperty("postres")).then().extract().response();
		
		String response=resp.asString();
		l.info(response);
		System.out.println(response);
		
		JsonPath json=new JsonPath(response);
		String id=json.get("id").toString();
		l.info(id);
		System.out.println(id);
		
		String msg=json.get("text").toString();
		l.info(msg);
		System.out.println(msg);
		
		
		
	
	}
	
}


