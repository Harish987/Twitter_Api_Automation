package Twitt_Api;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Username_get_twitter 
{
	
	
		Properties pro=new Properties();
		Logger l=Logger.getLogger("Username_get_twitter");
		
@BeforeTest
		
		public void start() throws Exception {
		
	        PropertyConfigurator.configure("C:\\New folder\\Twitter API Automation\\Log4j.properties");	
			FileInputStream f=new FileInputStream("C:\\New folder\\Twitter API Automation\\Data.properties");
			pro.load(f);
	}
	
@Test
	public void user_Tweet() throws IOException
	{
		
		
		RestAssured.baseURI=pro.getProperty("user");
		
	
		Response resp=given().auth().oauth(pro.getProperty("ConsumerKey"),pro.getProperty("ConsumerSecret"),pro.getProperty("Token"),pro.getProperty("TokenSecret")).
		queryParam("q","Qualitest")
		
		
		.when().get(pro.getProperty("userres")).then().extract().response();
		
	    String response=resp.asString();
	    l.info(response);
		System.out.println(response);
		
		JsonPath jsn=new JsonPath(response);
		int count=jsn.get("statuses.size()");
		l.info(count);
		System.out.println(count);
		   
		
		for(int i=0;i<count;i++) {
			 String Uname=jsn.getString("statuses["+i+"].user.screen_name");
			 l.info(Uname);
			 System.out.println("USER NAME   "+Uname);
		 }
		
	
	}
}
